#include <windows.h>
#include <gl/gl.h>
#include <gl/glut.h>
#include <math.h>

#define		PI	3.1415

int		polygon_num = 4;
float	radius = 100;


void  Modeling_Polygon(void) {
	float	x, y;
	double	delta;

	delta = 2 * PI / polygon_num;

	glColor3f(1.0, 1.0, 0.0);
	glPointSize(3.0);
	glBegin(GL_POLYGON);
	for (int i = 0; i < polygon_num; i++) {
		x = (float)(radius * cos(PI / 4.0 + delta * i));
		y = (float)(radius * sin(PI / 4.0 + delta * i));
		glVertex2f(x, y);
	}
	glEnd();
}

void Modeling_Axis(void) {
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex2i(-250, 0);
	glVertex2i(250, 0);
	glEnd();


	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
	glVertex2i(0, 250);
	glVertex2i(0, -250);
	glEnd();

}

void Camera_Lense_Setting(void) {
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-250.0, 250.0, -250.0, 250.0);
	//glOrtho(-250.0, 250.0, -250.0, 250.0,-1.0, 1.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void RenderScene(void) {
	glClearColor(0.5, 0.5, 0.5, 0.0);
	glClear(GL_COLOR_BUFFER_BIT);

	Camera_Lense_Setting();
	Modeling_Axis();
	Modeling_Polygon();


	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitWindowPosition(50, 150);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Welcome to Computer Graphics");
	glutDisplayFunc(RenderScene);
	glutMainLoop();
	return 0;
}